#pragma once

#include "common/IPrefix.h"
#include "nvse/nvse_version.h"
